using Microsoft.AspNetCore.Mvc;
using Models;
using Repositories;

namespace Controllers;

public class ProductsController : ControllerBase
{

}